// 
// Decompiled by Procyon v0.5.36
// 

package cc.saferoad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "cc.saferoad" })
public class SpringbootApplication
{
    public static void main(final String[] args) {
        SpringApplication.run((Class)SpringbootApplication.class, args);
    }
}
