// 
// Decompiled by Procyon v0.5.36
// 

package org.springframework.boot.loader.jar;

interface JarEntryFilter
{
    AsciiBytes apply(final AsciiBytes name);
}
